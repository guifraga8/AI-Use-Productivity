/**
 * @author Guilherme Fraga
 * @since 13/09/2025
 * @version 1.0
 */

const vehicleModels = [
  { description: "Moto", maxWeight: 45, vehicles: [] },
  { description: "Van", maxWeight: 3000, vehicles: [] },
  { description: "Kombi", maxWeight: 5000, vehicles: [] },
  { description: "Caminhão", maxWeight: 12000, vehicles: [] },
];

let items = [];
let remainingItems = [];

function controller() {
  getData();
  if (items.length === 0) {
    document.getElementById("result-text").value = "Nenhum item válido para processar.";
    return;
  }
  items.forEach(distributeItemsBetweenVehicles);
  showResult();
  clear();
}

function showResult() {
  let finalResult = "";
  const vehiclesWithItems = vehicleModels.filter((vehicle) => vehicle.vehicles.length > 0);

  let totalCapacity = 0;
  let totalWeight = 0;

  const vehicleResults = vehiclesWithItems.map((vehicle) => {
    const weightInVehicle = calculateWeightInVehicle(vehicle);
    totalCapacity += calculateTotalCapacity(vehicle);
    totalWeight += weightInVehicle;
    return toStringVehicleType(vehicle);
  });

  finalResult += vehicleResults.join("");

  const totalRemainingSpace = totalCapacity - totalWeight;
  const totalPercentageLoaded = ((totalWeight / (totalCapacity || 1)) * 100).toFixed(2);

  finalResult += `\nCapacidade total: ${totalCapacity}kg\n`;
  finalResult += `Peso total: ${totalWeight}kg\n`;
  finalResult += `Espaço de sobra: ${totalRemainingSpace}kg\n`;
  finalResult += `Percentual carregado: ${totalPercentageLoaded}%`;

  if (remainingItems.length > 0) {
    finalResult += "\n\n";
    finalResult += "Itens com peso excedente: \n";
    finalResult += remainingItems.map((item) => toStringItem(item)).join("");
  }

  document.getElementById("result-text").value = finalResult;
}

function clear() {
  vehicleModels.forEach((vehicle) => {
    vehicle.vehicles = [];
  });
  items = [];
}

function toStringVehicleType(vehicleModel) {
  return vehicleModel.vehicles
    .map((vehicle, index) => {
      return `${vehicleModel.description} ${index + 1}: \n${vehicle.items.map(toStringItem).join("")}`;
    })
    .join("");
}

function toStringItem(item) {
  return `${item.weight}kg ${item.description}\n`;
}

function getData() {
  const data = document.getElementById("data").value.trim();
  items = data
    .split("\n")
    .map((line) => {
      line = line.trim();
      if (!line) return null;

      const match = line.match(/^(\d+)\s*kg(.*)$/i);
      if (!match) return null;

      const weight = parseInt(match[1], 10);
      const description = match[2].trim();
      return { weight, description };
    })
    .filter((item) => item !== null);
}

function clearTextArea() {
  document.getElementById("data").value = "";
  document.getElementById("result-text").value = "";
}

function distributeItemsBetweenVehicles(item) {
  let itemOk = false;
  for (let vehicle of vehicleModels) {
    if (item.weight <= vehicle.maxWeight) {
      distributeItemInVehicle(vehicle, item);
      itemOk = true;
      break;
    }
  }

  if (!itemOk) {
    remainingItems.push(item);
  }
}

function distributeItemInVehicle(vehicle, item) {
  if (vehicle.vehicles.length === 0) {
    vehicle.vehicles.push({
      items: [item],
      weight: item.weight,
    });
    return;
  }

  const lastVehicle = vehicle.vehicles[vehicle.vehicles.length - 1];
  const currentWeight = lastVehicle.weight;

  if (currentWeight + item.weight <= vehicle.maxWeight) {
    lastVehicle.items.push(item);
    lastVehicle.weight += item.weight;
  } else {
    vehicle.vehicles.push({
      items: [item],
      weight: item.weight,
    });
  }
}

function calculateWeightInVehicle(vehicle) {
  return vehicle.vehicles.reduce((prev, curr) => prev + curr.weight, 0);
}

function calculateTotalCapacity(vehicle) {
  return vehicle.vehicles.length * vehicle.maxWeight;
}
