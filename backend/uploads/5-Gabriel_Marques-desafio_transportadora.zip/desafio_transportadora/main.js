/**
 * @author Guilherme Fraga
 * @since 13/09/2025
 * @version 2.0
 */

const vehicles = [
    { description: "Moto", maxWeight: 45, vehicles: [] },
    { description: "Van", maxWeight: 3000, vehicles: [] },
    { description: "Kombi", maxWeight: 5000, vehicles: [] },
    { description: "Caminhão", maxWeight: 12000, vehicles: [] },
];

let items = [];

function controller() {
    resetArrays();
    getData();

    if (items.length === 0) {
        document.getElementById("result-text").value = "Nenhum item válido para processar.";
        return;
    }

    items.forEach(distributeItemsBetweenVehicles);
    showResult();
}

function getData() {
    const data = document.getElementById("data").value.trim();
    const lines = data.split('\n');

    items = lines.map(line => {
        line = line.trim();
        if (!line) return null;

        // Regex para capturar variações de "kg"
        const match = line.match(/^(\d+)\s*(kg|KG|Kg|kG)\s*(.+)$/i);
        if (!match) return null;

        const weight = parseInt(match[1], 10);
        const description = match[3].trim();

        return { weight, description };
    }).filter(item => item !== null);
}

function distributeItemsBetweenVehicles(item) {
    for (let vehicle of vehicles) {
        if (item.weight <= vehicle.maxWeight) {
            distributeItemInVehicle(vehicle, item);
            break;
        }
    }
}

function distributeItemInVehicle(vehicle, item) {
    if (vehicle.vehicles.length === 0) {
        vehicle.vehicles.push([item]);
        return;
    }

    const lastUnit = vehicle.vehicles[vehicle.vehicles.length - 1];
    const currentWeight = lastUnit.reduce((sum, it) => sum + it.weight, 0);

    if (currentWeight + item.weight <= vehicle.maxWeight) {
        lastUnit.push(item);
    } else {
        vehicle.vehicles.push([item]);
    }
}

function showResult() {
    let finalResult = "";
    let totalCapacity = 0;
    let totalWeight = 0;

    const vehiclesWithItems = vehicles.filter(v => v.vehicles.length > 0);

    const vehicleResults = vehiclesWithItems.map(vehicle => {
        const vehicleText = vehicle.vehicles.map((unit, index) => {
            const itemsText = unit.map(item => `${item.weight}kg ${item.description}`).join('\n');
            const title = `${vehicle.description} ${index + 1}:\n`;
            const block = `${title}${itemsText}\n`;
            const weightInVehicle = unit.reduce((sum, item) => sum + item.weight, 0);
            totalWeight += weightInVehicle;
            totalCapacity += vehicle.maxWeight;
            return block;
        }).join('');
        return vehicleText;
    });

    finalResult += vehicleResults.join('\n');

    const totalRemainingSpace = totalCapacity - totalWeight;
    const totalPercentageLoaded = ((totalWeight / (totalCapacity || 1)) * 100).toFixed(2);

    finalResult += `\nCapacidade total: ${totalCapacity}kg\n`;
    finalResult += `Peso total: ${totalWeight}kg\n`;
    finalResult += `Espaço de sobra: ${totalRemainingSpace}kg\n`;
    finalResult += `Percentual carregado: ${totalPercentageLoaded}%`;

    document.getElementById("result-text").value = finalResult;
}

function clearTextArea() {
    document.getElementById("data").value = "";
    document.getElementById("result-text").value = "";
}

function resetArrays() {
    vehicles.forEach(vehicle => {
        vehicle.vehicles = [];
    });
    items = [];
}
